
<footer class="footer">
<div class="container">
<div class="dash" data-dash aria-hidden="true"></div>
<div class="footer__grid">
<div class="footer__brand" data-reveal>
<a class="footer__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Scalium" data-home-link>
<img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/logo-horizontal.svg" alt="Scalium" width="157" height="32" loading="lazy">
</a>
<p class="footer__tag" data-i18n="footer.tag">Automate today. A bigger tomorrow.</p>
<ul class="social" aria-label="Social media" data-i18n-attr="aria-label:social.label">
<li><a class="social__link" href="<?php echo esc_url( scalium_setting( 'instagram' ) ); ?>" target="_blank" rel="noopener" aria-label="Instagram"><svg class="icon" aria-hidden="true"><use href="#i-instagram-logo"/></svg></a></li>
<li><a class="social__link" href="<?php echo esc_url( scalium_setting( 'tiktok' ) ); ?>" target="_blank" rel="noopener" aria-label="TikTok"><svg class="icon" aria-hidden="true"><use href="#i-tiktok-logo"/></svg></a></li>
</ul>
</div>
<nav class="footer__col" aria-labelledby="f-services" data-reveal style="--d:1">
<p class="footer__head" id="f-services" data-i18n="nav.services">Services</p>
<a class="link" href="<?php echo esc_url( home_url( '/#services' ) ); ?>" data-i18n="svc1.short">Meta Ads scaling</a>
<a class="link" href="<?php echo esc_url( home_url( '/#services' ) ); ?>" data-i18n="svc2.short">Marketing management</a>
<a class="link" href="<?php echo esc_url( home_url( '/#services' ) ); ?>" data-i18n="svc3.short">Growth marketing</a>
</nav>
<nav class="footer__col" aria-labelledby="f-company" data-reveal style="--d:2">
<p class="footer__head" id="f-company" data-i18n="footer.company">Company</p>
<a class="link" href="<?php echo esc_url( home_url( '/#process' ) ); ?>" data-i18n="nav.process">Process</a>
<a class="link" href="<?php echo esc_url( home_url( '/#results' ) ); ?>" data-i18n="nav.results">Results</a>
<a class="link" href="<?php echo esc_url( scalium_contact_url() ); ?>" data-transition data-i18n="cta.contact">Contact us</a>
</nav>
<div class="footer__col" data-reveal style="--d:3">
<p class="footer__head" data-i18n="lang.label">Language</p>
<div class="lang lang--footer" role="group" aria-label="Language" data-i18n-attr="aria-label:lang.label">
<button type="button" class="lang__opt" data-lang="en" aria-pressed="true" lang="en">English</button>
<button type="button" class="lang__opt" data-lang="ro" aria-pressed="false" lang="ro">Română</button>
<span class="lang__thumb" aria-hidden="true"></span>
</div>
</div>
</div>
<div class="footer__bottom">
<p>&copy; <span data-year>2026</span> Scalium. <span data-i18n="footer.rights">All rights reserved.</span></p>
<button type="button" class="to-top" data-to-top>
<span data-i18n="footer.top">Back to top</span>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-up"/></svg>
</button>
</div>
</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
