<?php get_header(); ?>

<main id="main">
<section class="hero" id="top" aria-labelledby="hero-title">
<div class="hero__bg" aria-hidden="true">
<svg class="trails" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" focusable="false">
<defs>
<linearGradient id="trail-fade" x1="0" y1="0" x2="1" y2="0">
<stop offset="0" stop-color="#4d94ff" stop-opacity="0"/>
<stop offset=".45" stop-color="#4d94ff" stop-opacity=".22"/>
<stop offset="1" stop-color="#4d94ff" stop-opacity=".05"/>
</linearGradient>
</defs>
<g class="trails__base" stroke="url(#trail-fade)" fill="none" stroke-width="1">
<path d="M-40 760C380 720 760 600 1640 260"/>
<path d="M-40 842C460 822 980 702 1640 520"/>
<path d="M420 940C700 700 1080 520 1640 420"/>
<path d="M-40 430C300 470 520 600 760 940"/>
</g>
<g class="trails__comets" fill="none" stroke-linecap="round">
<path pathLength="1000" style="--dur:7.5s;--delay:-1.2s" d="M-40 760C380 720 760 600 1640 260"/>
<path pathLength="1000" style="--dur:9s;--delay:-5s" d="M-40 842C460 822 980 702 1640 520"/>
<path pathLength="1000" style="--dur:8.2s;--delay:-3.4s" d="M420 940C700 700 1080 520 1640 420"/>
<path pathLength="1000" style="--dur:10s;--delay:-7s" d="M-40 430C300 470 520 600 760 940"/>
</g>
</svg>
<div class="hero__glow"></div>
<div class="hero__horizon"></div>
</div>
<div class="container hero__grid">
<div class="hero__copy" data-hero-copy>
<p class="hero__eyebrow"><span class="dash is-on" aria-hidden="true"></span><span data-i18n-html="hero.eyebrow">Meta Ads <span>&times;</span> AI <span>&times;</span> Growth</span></p>
<h1 class="hero__title" id="hero-title" data-i18n-html="hero.title"><span class="line"><span>Scale smarter</span></span> <span class="line"><span>with <em>Meta Ads.</em></span></span></h1>
<p class="hero__lead" data-i18n="hero.lead">We help eCommerce brands scale profitably with data-driven Meta Ads, AI optimization and performance-focused strategy.</p>
<div class="hero__ctas">
<a class="btn btn--primary" href="<?php echo esc_url( scalium_contact_url() ); ?>" data-transition>
<span data-i18n="cta.contact">Contact us</span>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-right"/></svg>
</a>
<a class="btn btn--ghost" href="#services">
<span data-i18n="hero.secondary">See our services</span>
<svg class="icon icon--down" aria-hidden="true"><use href="#i-arrow-right"/></svg>
</a>
</div>
</div>
<div class="hero__visual" data-hero-visual>
<div class="hero__tilt" data-tilt>
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-560.avif 560w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-900.avif 900w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-1200.avif 1200w" sizes="(min-width: 1024px) 60vw, 100vw"><img class="hero__img" src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-900.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-560.webp 560w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-900.webp 900w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-1200.webp 1200w" sizes="(min-width: 1024px) 60vw, 100vw" width="972" height="750" alt="Scalium Meta Ads dashboard with total revenue, ROAS and active ad campaigns" data-i18n-attr="alt:hero.alt" fetchpriority="high" loading="eager" decoding="async"></picture>
</div>
</div>
</div>
</section>
<section class="statement" aria-labelledby="statement-text">
<div class="container">
<p class="statement__text" id="statement-text" data-scrub-words data-i18n="statement.text">Most brands don't have a traffic problem. They have a scaling problem. We build the system that turns ad spend into predictable revenue.</p>
<ul class="outcomes">
<li class="outcome" data-reveal style="--d:0">
<span class="dash" data-dash aria-hidden="true"></span>
<svg class="icon" aria-hidden="true"><use href="#i-trend-up"/></svg>
<span data-i18n="outcome.1">More revenue</span>
</li>
<li class="outcome" data-reveal style="--d:1">
<span class="dash" data-dash aria-hidden="true"></span>
<svg class="icon" aria-hidden="true"><use href="#i-target"/></svg>
<span data-i18n="outcome.2">Lower CAC</span>
</li>
<li class="outcome" data-reveal style="--d:2">
<span class="dash" data-dash aria-hidden="true"></span>
<svg class="icon" aria-hidden="true"><use href="#i-lightning"/></svg>
<span data-i18n="outcome.3">Long-term growth</span>
</li>
</ul>
</div>
</section>
<section class="services" id="services" aria-labelledby="services-title">
<div class="container">
<div class="section-head" data-reveal>
<div class="dash" data-dash aria-hidden="true"></div>
<h2 class="h2" id="services-title" data-i18n="services.title">Three services. One goal: profitable growth.</h2>
<p class="section-lead" data-i18n="services.lead">Choose one or combine all three. The same team, the same data and the same target behind each of them.</p>
</div>
<div class="services__layout" data-services>
<div class="services__list">
<article class="service is-active" data-service="0" aria-labelledby="svc1-title">
<div class="service__media">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.avif 1040w" sizes="(min-width: 960px) 1px, 92vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.webp 1040w" sizes="(min-width: 960px) 1px, 92vw" width="702" height="492" alt="" loading="lazy" decoding="async"></picture>
</div>
<h3 class="service__title" id="svc1-title" data-i18n="svc1.title">Brand scaling with Meta Ads</h3>
<p class="service__text" data-i18n="svc1.text">Facebook and Instagram campaigns built to grow spend without losing efficiency. We structure the account, find the audiences that buy and scale budgets on the signals that matter.</p>
<ul class="service__list">
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d1">Full-funnel campaign structure</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d2">Audience research and targeting</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d3">Budget scaling and bid strategy</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d4">Advantage+ and catalog campaigns</span></li>
</ul>
</article>
<article class="service" data-service="1" aria-labelledby="svc2-title">
<div class="service__media">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.avif 940w" sizes="(min-width: 960px) 1px, 92vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.webp 940w" sizes="(min-width: 960px) 1px, 92vw" width="470" height="360" alt="" loading="lazy" decoding="async"></picture>
</div>
<h3 class="service__title" id="svc2-title" data-i18n="svc2.title">Marketing, run for you</h3>
<p class="service__text" data-i18n="svc2.text">We run your marketing day to day: creative production and testing, launches, reporting and optimization. You get a senior team without building one in-house.</p>
<ul class="service__list">
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d1">Creative strategy and production</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d2">Continuous creative testing</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d3">Campaign launches and promotions</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d4">Clear weekly reporting</span></li>
</ul>
</article>
<article class="service" data-service="2" aria-labelledby="svc3-title">
<div class="service__media">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.avif 1040w" sizes="(min-width: 960px) 1px, 92vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.webp 1040w" sizes="(min-width: 960px) 1px, 92vw" width="548" height="276" alt="" loading="lazy" decoding="async"></picture>
</div>
<h3 class="service__title" id="svc3-title" data-i18n="svc3.title">Growth marketing</h3>
<p class="service__text" data-i18n="svc3.text">Growth comes from the whole funnel, not a single channel. We test offers, landing pages and retention flows, fix tracking and use the data to find your next stage of growth.</p>
<ul class="service__list">
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d1">Conversion rate optimization</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d2">Tracking with Pixel, CAPI and GA4</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d3">Offer and funnel experiments</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d4">Retention and LTV strategy</span></li>
</ul>
</article>
</div>
<div class="services__stage" aria-hidden="true">
<div class="stage">
<div class="stage__frame">
<div class="stage__slide is-active" data-slide="0">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.avif 1040w" sizes="(min-width: 960px) 46vw, 1px"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.webp 1040w" sizes="(min-width: 960px) 46vw, 1px" width="702" height="492" alt="" loading="lazy" decoding="async"></picture>
</div>
<div class="stage__slide" data-slide="1">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.avif 940w" sizes="(min-width: 960px) 40vw, 1px"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.webp 940w" sizes="(min-width: 960px) 40vw, 1px" width="470" height="360" alt="" loading="lazy" decoding="async"></picture>
</div>
<div class="stage__slide" data-slide="2">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.avif 1040w" sizes="(min-width: 960px) 46vw, 1px"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.webp 1040w" sizes="(min-width: 960px) 46vw, 1px" width="548" height="276" alt="" loading="lazy" decoding="async"></picture>
</div>
<span class="stage__scan" data-scan></span>
</div>
<div class="stage__progress"><span class="is-active"></span><span></span><span></span></div>
</div>
</div>
</div>
</div>
</section>
<section class="process" id="process" aria-labelledby="process-title">
<div class="process__pin" data-process>
<div class="process__track" data-process-track>
<div class="process__intro" data-reveal>
<div class="dash" data-dash aria-hidden="true"></div>
<h2 class="h2" id="process-title" data-i18n="process.title">From first ad to predictable scale.</h2>
<p class="section-lead" data-i18n="process.lead">Five stages, one loop. Every cycle feeds the next one with better data.</p>
<div class="process__emblem">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-420.avif 420w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-700.avif 700w" sizes="(min-width: 960px) 30vw, 80vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-700.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-420.webp 420w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-700.webp 700w" sizes="(min-width: 960px) 30vw, 80vw" width="352" height="232" alt="" loading="lazy" decoding="async"></picture>
</div>
</div>
<div class="process__steps" data-process-steps>
<div class="process__line" aria-hidden="true"><span class="process__fill" data-process-fill></span><span class="process__head" data-process-head></span></div>
<ol class="steps">
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-sparkle"/></svg><span data-i18n="step1.title">Create</span></h3>
<p class="step__text" data-i18n="step1.text">Ad creatives built on research and produced fast with AI, ready to test from day one.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-paper-plane-tilt"/></svg><span data-i18n="step2.title">Launch</span></h3>
<p class="step__text" data-i18n="step2.text">Campaigns go live across Facebook and Instagram with a clear testing plan.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-chart-bar"/></svg><span data-i18n="step3.title">Analyze</span></h3>
<p class="step__text" data-i18n="step3.text">We read the numbers that matter and turn them into decisions, not just reports.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-gear-six"/></svg><span data-i18n="step4.title">Automate</span></h3>
<p class="step__text" data-i18n="step4.text">Rules and AI-assisted optimization keep budgets working around the clock.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-trend-up"/></svg><span data-i18n="step5.title">Scale</span></h3>
<p class="step__text" data-i18n="step5.text">Winning ads and audiences get more budget, so growth stays profitable as spend increases.</p>
</div>
</li>
</ol>
</div>
</div>
</div>
</section>
<section class="results" id="results" aria-labelledby="results-title">
<div class="container">
<div class="section-head section-head--center" data-reveal>
<h2 class="h2" id="results-title" data-i18n-html="results.title">Data-driven <em>growth.</em></h2>
<p class="section-lead" data-i18n="results.lead">Every decision is backed by numbers. These are the metrics we answer for.</p>
</div>
</div>
<div class="results__media" data-zoom>
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-640.avif 640w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1000.avif 1000w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1400.avif 1400w" sizes="(min-width: 1400px) 1300px, 94vw"><img class="results__img" src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1000.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-640.webp 640w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1000.webp 1000w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1400.webp 1400w" sizes="(min-width: 1400px) 1300px, 94vw" width="1214" height="554" alt="Performance dashboard with ad spend, conversions and a rising revenue chart" data-i18n-attr="alt:results.alt" loading="lazy" decoding="async"></picture>
</div>
<div class="container">
<dl class="stats" data-reveal>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-chart-bar"/></svg><span>ROAS</span></dt>
<dd data-count="42" data-sign="+">+42%</dd>
</div>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-users-three"/></svg><span data-i18n="stat.leads">Leads</span></dt>
<dd data-count="68" data-sign="+">+68%</dd>
</div>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-trend-up"/></svg><span data-i18n="stat.revenue">Revenue</span></dt>
<dd data-count="53" data-sign="+">+53%</dd>
</div>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-target"/></svg><span>CAC</span></dt>
<dd data-count="37" data-sign="&minus;">&minus;37%</dd>
</div>
</dl>
<p class="footnote" data-i18n="results.note">Illustrative figures. Results depend on brand, offer and budget.</p>
</div>
</section>
<section class="cta" id="contact-cta" aria-labelledby="cta-title">
<div class="container cta__content">
<h2 class="cta__title" id="cta-title" data-reveal data-i18n="cta.title">Growing together.</h2>
<p class="cta__sub" data-reveal style="--d:1" data-i18n="cta.sub">Meta Ads. Marketing. Growth Marketing.</p>
<div class="cta__action" data-reveal style="--d:2">
<a class="btn btn--primary btn--lg" href="<?php echo esc_url( scalium_contact_url() ); ?>" data-transition>
<span data-i18n="cta.button">Contact us for more information and pricing</span>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-right"/></svg>
</a>
</div>
</div>
<div class="cta__media" data-cta-media aria-hidden="true">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-800.avif 800w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.avif 1280w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1672.avif 1672w" sizes="100vw"><img class="cta__img" src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-800.webp 800w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.webp 1280w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1672.webp 1672w" sizes="100vw" width="1672" height="609" alt="" loading="lazy" decoding="async"></picture>
</div>
</section>
</main>

<?php get_footer();
