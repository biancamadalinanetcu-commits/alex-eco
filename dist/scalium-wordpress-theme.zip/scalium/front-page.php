<?php get_header(); ?>

<main id="main">
<div class="intro-wrap" data-intro-wrap>
<div class="intro" data-intro aria-hidden="true">
<div class="intro__bg"></div>
<div class="intro__scene">
<div class="intro__tunnel">
<span class="intro__ring" style="--z:-300px;--s:1.35"></span>
<span class="intro__ring" style="--z:-850px;--s:1.5"></span>
<span class="intro__ring" style="--z:-1400px;--s:1.4"></span>
<span class="intro__ring" style="--z:-1950px;--s:1.55"></span>
<span class="intro__ring" style="--z:-2500px;--s:1.45"></span>
<span class="intro__ring" style="--z:-3050px;--s:1.6"></span>
<span class="intro__ring" style="--z:-3600px;--s:1.5"></span>
<span class="intro__ring" style="--z:-4150px;--s:1.6"></span>
</div>
<div class="intro__logo">
<div class="intro__mark" data-intro-mark>
<span class="intro__piece intro__blade" style="--ox:29.06%;--oy:77.06%"><svg viewBox="466 410 320 235" focusable="false"><path fill="#0a6aff" fill-rule="evenodd" d="M 601.1 542.2 L 570.1 542.4 567.6 543.3 C 566.3 543.8,563.9 544.8,562.5 545.6 L 559.9 546.9 557 549.8 C 552.5 554.5,512.3 594.6,501.1 605.6 C 474.4 631.9,471 635.3,470.7 636.3 C 470.2 637.9,471.4 639.3,473.6 639.7 C 475.9 640.1,545.4 640.1,546.9 639.7 C 550.6 638.6,553.5 637.3,555.3 635.9 C 557.6 634.2,635 556.9,644.3 547 C 647.5 543.7,647.8 543.1,647.2 542.5 C 646.7 542.1,637.1 542.1,601.1 542.2"/></svg></span>
<span class="intro__piece intro__arrow" style="--ox:72.73%;--oy:47.77%"><svg viewBox="466 410 320 235" focusable="false"><path fill="#0a6aff" fill-rule="evenodd" d="M 697.1 416.6 C 696.7 416.8,695.7 417.6,694.9 418.5 C 692.7 420.8,672 441.1,670 442.9 C 669.1 443.7,667.9 444.9,667.4 445.5 C 666.8 446.1,664.9 447.9,663.1 449.6 C 660.1 452.4,648.4 463.7,636.5 475.4 C 633.5 478.3,630.2 481.5,629 482.5 C 626.3 484.9,615.6 495.5,615.1 496.3 C 614.7 497.1,614.8 497.6,615.7 498 C 616.1 498.2,623.3 498.3,641.9 498.3 L 667.5 498.3 668 498.9 L 668.5 499.6 668.5 561.4 C 668.5 628.8,668.4 624.3,669.9 625 C 670.3 625.1,670.7 625.2,670.9 625 C 671.3 624.8,679 617.4,690.4 606.3 C 698.2 598.6,713.7 583.5,718.2 579.1 C 719.9 577.5,721.8 575.7,722.4 575.1 C 723.9 573.6,725.8 570.6,726.3 568.8 C 726.6 567.9,727.1 566.5,727.5 565.6 L 728.1 564.1 728.2 532.1 C 728.2 514.5,728.3 499.9,728.4 499.6 C 728.7 498.2,727.9 498.3,755.2 498.3 C 782.8 498.3,782.3 498.3,782.3 496.9 C 782.3 496.2,776.7 490.6,770.7 485.3 C 768.8 483.6,765.4 480.4,763.4 478.4 C 758.9 473.9,736.9 452.5,732.9 448.8 C 731.3 447.3,727.1 443.1,723.3 439.4 C 719.6 435.8,716.2 432.5,715.8 432.2 C 715.4 431.8,711.7 428.2,707.7 424.2 C 699.4 415.9,699.2 415.7,697.1 416.6"/></svg></span>
<span class="intro__sheen"></span>
</div>
<div class="intro__word">
<span class="intro__letter" style="--ox:7.44%;--oy:63.51%;--i:0;--dx:-0.851"><svg viewBox="280 662 694 164" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M 324.5 711 C 312.3 713.1,304.3 716.6,298 722.7 C 287.2 733,285.9 750.7,295.2 761.8 C 299.8 767.3,310.2 772.8,319.9 774.9 C 320.3 775,321.4 775.3,322.3 775.5 C 323.1 775.7,325 776.2,326.4 776.5 C 343.2 780.2,347.3 781.8,349.3 785.6 C 351.8 790.4,348.2 795.4,341.1 797.2 C 330.2 799.8,317 795.9,306.7 787.1 C 304.9 785.5,303.8 784.8,303.4 784.8 C 302.8 784.8,301.6 785.7,296.7 790 C 293.4 793,285.3 799.8,284.9 800.1 C 283.3 800.9,283.6 802.3,285.9 804.5 C 293.3 811.6,304.4 817.7,312.6 819.2 C 313.3 819.4,314.2 819.6,314.5 819.7 C 314.8 819.8,315.7 820,316.5 820.1 C 317.3 820.2,318.4 820.4,319.1 820.6 C 324.2 822,343.1 822,347.5 820.6 C 348.1 820.4,349.2 820.2,349.9 820.1 C 355.2 819.4,363.9 815.4,368.6 811.6 C 376.2 805.2,380 797,380 786.7 C 380 782,380 781.9,378.6 777.4 C 375.6 768,367.4 761,354.8 756.7 C 352.5 756,348.2 754.9,339.4 752.7 C 327.5 749.9,324.8 749,322.4 747.4 C 320.2 745.9,319 744,319 741.8 C 319 730.1,347.4 730.8,358.5 742.8 C 359.8 744.3,359.3 744.6,370.6 734.2 C 372.7 732.4,375.1 730.2,376.1 729.4 C 378.7 727.1,378.6 726.3,375 723.4 C 368 717.8,359.2 713.6,350.4 711.8 C 344.2 710.5,343.3 710.4,335.9 710.3 L 328.6 710.3 324.5 711"/></svg></span>
<span class="intro__letter" style="--ox:22.53%;--oy:63.45%;--i:1;--dx:-0.549"><svg viewBox="280 662 694 164" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M 436.9 710.4 C 425.2 711.9,419.8 713.7,411.4 718.5 C 398.8 725.7,389 738.6,386.2 751.9 C 386.1 752.6,385.8 753.7,385.6 754.4 C 385.4 755.1,385.2 756.4,385.1 757.3 C 385.1 758.1,384.9 760.4,384.7 762.3 C 384.4 766.2,384.8 773.4,385.4 776.8 C 385.6 777.8,385.9 779.1,386 779.8 C 386.4 782.3,388.1 786.6,390.1 790.9 C 394.4 799.6,401.4 807.5,409.7 812.9 C 413.5 815.4,424.1 820,426 820 C 426.2 820,427 820.2,427.8 820.4 C 429.2 820.8,432.8 821.3,437.9 821.8 C 442 822.2,451.4 821.5,454.3 820.6 C 454.9 820.4,455.9 820.2,456.5 820.1 C 457 820,458.5 819.6,459.7 819.2 C 460.9 818.8,462.4 818.3,463 818.1 C 464.3 817.7,469.4 815.1,471.7 813.7 C 478.2 809.8,488.3 799.7,488.3 797.2 C 488.3 796.3,487.7 795.7,484.3 793.4 C 483 792.4,480.6 790.8,479.1 789.8 C 477.7 788.7,475.3 787,473.9 786 C 470.2 783.3,466.7 781,466.2 781 C 465.8 781,464.7 782.1,463.4 783.9 C 461 787.3,452.5 793,449.9 793 C 449.7 793,448.9 793.2,448.2 793.5 L 446.9 794.1 441.6 794.1 L 436.4 794.1 434 793.3 C 427 790.8,422.1 787.3,418.7 782 C 417.2 779.9,415.3 775.8,415.3 775 C 415.3 774.9,415 774,414.7 773.2 L 414.1 771.6 414.1 765.9 L 414.1 760.1 414.7 758.3 C 418.9 745,429.4 737.6,443.1 738.1 C 452 738.4,458.1 741.6,464.8 749.2 C 466.3 750.9,466 751,472 746.6 C 474.7 744.7,477.9 742.3,479.3 741.4 C 486.4 736.6,488.3 735.1,488.3 734.2 C 488.3 732.1,479.3 723.2,472.8 718.8 C 469.6 716.6,461 713.1,455.8 711.9 C 450.4 710.6,440.9 709.9,436.9 710.4"/></svg></span>
<span class="intro__letter" style="--ox:38.23%;--oy:63.84%;--i:2;--dx:-0.235"><svg viewBox="280 662 694 164" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M 536.1 711.4 C 531.5 712.1,529.7 712.5,523.8 714.4 C 509.6 719.1,497.9 730.6,492.6 745 C 490.2 751.5,489.6 754.1,489 760.5 C 488.2 769.9,489.4 779.7,492.1 786.6 C 496.9 799,504.4 807.8,516.3 815.2 C 520.2 817.7,527.7 820.3,532.6 821 C 533.6 821.1,535 821.4,535.8 821.5 C 538.9 822.1,551 821.4,552.2 820.6 C 552.4 820.5,553.1 820.3,553.8 820.1 C 559.4 818.7,565.9 814.8,570.5 810.2 C 571.7 809,572.8 808,573 808 L 573.5 808 573.5 812.9 C 573.5 818.1,573.6 818.8,574.7 819.2 C 575.2 819.4,579.4 819.5,588.3 819.4 L 601.2 819.4 601.8 818.9 L 602.3 818.3 602.4 777.6 C 602.4 755.2,602.4 732,602.3 726 L 602.2 715.2 601.7 714.7 L 601.2 714.2 588 714.3 L 574.7 714.4 574.2 715.1 C 573.8 715.6,573.7 716.1,573.6 717.8 C 573.6 718.9,573.6 721,573.5 722.3 L 573.5 724.8 573 724.8 C 572.6 724.8,571.5 723.9,569.9 722.3 C 562.3 715,553.4 711.5,542 711.4 C 539.2 711.3,536.5 711.4,536.1 711.4 M 542.3 738.5 C 517.5 741.7,509.3 773,529.1 788.7 C 531.6 790.7,534.2 792,539 793.5 L 540.9 794.1 545.9 794.1 L 550.9 794.1 553.9 793 C 560.5 790.8,565.6 787,569.4 781.3 C 571.1 778.7,572 776.6,573.5 771.3 C 574.1 769.1,574.2 764.6,573.6 762 C 573.4 760.9,573.1 759.7,573 759.1 C 572.9 758.6,572.3 756.9,571.7 755.3 C 566.8 743.8,554.7 736.9,542.3 738.5"/></svg></span>
<span class="intro__letter" style="--ox:50.19%;--oy:50.03%;--i:3;--dx:0.004"><svg viewBox="280 662 694 164" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M 615 669.6 C 613.7 670.2,613.8 666.4,613.6 744.4 C 613.5 822.1,613.5 818.7,614.7 819.2 C 615.6 819.6,641.1 819.6,641.8 819.2 C 643.1 818.5,643 823.3,643 744.4 C 643 664.8,643.1 670.2,641.6 669.5 C 640.7 669.1,615.9 669.1,615 669.6"/></svg></span>
<span class="intro__letter" style="--ox:56.37%;--oy:49.76%;--i:4;--dx:0.127"><svg viewBox="280 662 694 164" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M 668.6 668 C 662.3 668.7,656.8 673.3,654.6 679.8 C 654.2 680.9,654.1 681.9,654.1 685.3 L 654.1 689.4 655.2 691.7 C 657.2 695.9,659.1 698,662.7 699.9 C 674.4 706.1,688.3 698,688.3 685 C 688.3 676,682.3 669.1,673.3 668 C 671 667.7,670.9 667.7,668.6 668 M 657.8 714.4 C 657.6 714.5,657.3 714.9,657.1 715.3 L 656.7 716.1 656.7 767 C 656.7 795,656.8 818.1,656.9 818.3 C 657.3 819.5,657.7 819.5,671.3 819.5 C 685.1 819.5,685.1 819.5,685.7 818.1 C 686 817.4,686.2 717.9,685.8 716.3 C 685.8 715.9,685.4 715.2,685.1 714.9 L 684.5 714.3 671.3 714.3 C 664.1 714.3,658 714.3,657.8 714.4"/></svg></span>
<span class="intro__letter" style="--ox:67.59%;--oy:64.82%;--i:5;--dx:0.352"><svg viewBox="280 662 694 164" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M 699.9 714.9 L 699.2 715.5 699.3 748.4 L 699.4 781.4 700 784 C 701 788.8,702.2 792.6,703.4 795.1 C 710.4 809,720 816.7,735.1 820.6 C 739.3 821.6,749.2 822.3,753.4 821.8 C 754.3 821.6,756.4 821.4,758 821.2 C 771.6 819.4,783.3 812.1,791 800.8 C 791.6 799.9,792.3 798.8,792.5 798.5 C 794.6 795.4,797.7 786.8,798.1 783 C 798.2 782.1,798.4 780.7,798.6 779.9 C 798.9 778.6,799 773.1,799 746.8 L 799 715.3 798.5 714.8 L 798 714.3 784.8 714.3 L 771.6 714.3 771 714.7 L 770.4 715.2 770.3 745.5 L 770.1 775.9 769.4 778.4 C 767.4 785.7,763.2 790.2,756 793 L 753.1 794.1 748.8 794.1 L 744.4 794.1 742.5 793.4 C 734.1 790.6,728.7 783.4,728.3 774.7 C 728.3 773,728.2 758.9,728.2 743.4 L 728.1 715.2 727.5 714.7 L 726.9 714.3 713.7 714.3 L 700.5 714.3 699.9 714.9"/></svg></span>
<span class="intro__letter" style="--ox:87.90%;--oy:62.41%;--i:6;--dx:0.758"><svg viewBox="280 662 694 164" focusable="false"><path fill="#fff" fill-rule="evenodd" d="M 864.6 711.4 C 854.2 712.5,845.7 716.9,840.6 723.8 C 838.8 726.2,838.5 725.6,838.5 719.9 L 838.5 715.6 838 714.9 L 837.5 714.3 824.2 714.3 L 810.8 714.3 810.2 714.9 L 809.6 715.5 809.6 766.6 C 809.5 803.2,809.6 817.8,809.8 818.3 C 810.3 819.5,810.5 819.5,824.3 819.4 L 837.2 819.4 837.8 818.8 L 838.4 818.2 838.5 787.3 C 838.7 753.4,838.6 754.4,840.2 750.6 C 841.8 746.6,845.5 742.5,848.8 740.9 C 855.8 737.6,865 738.7,869.5 743.4 C 871.7 745.7,874.2 750.6,874.3 752.6 C 874.3 753,874.4 754,874.6 754.8 C 874.9 755.9,875 760.6,875 786.9 C 875 809.3,875.1 817.9,875.3 818.3 C 875.8 819.5,876.1 819.5,889.8 819.4 L 902.7 819.4 903.3 818.8 L 903.9 818.2 904 787.1 L 904.1 755.9 904.8 753.6 C 907.5 744.1,914.2 739,923.9 739 C 931.3 739,936.8 742.7,939.6 749.6 C 941.3 753.6,941.3 753.4,941.3 787.2 C 941.3 820.2,941.2 818.5,942.6 819.2 C 943.1 819.4,946.7 819.5,956.2 819.5 L 969 819.5 969.8 818.8 L 970.5 818 970.5 785.5 C 970.5 757.9,970.4 752.6,970.1 749.7 C 968.7 737.7,964.4 728.3,957.5 722 C 951.7 716.8,948.1 714.7,941.8 713 C 925.4 708.5,908.1 713.9,899 726.3 C 897.7 728.2,897.4 728.2,895.8 725.9 C 891.3 719.5,886 715.7,878.3 713.1 C 874.4 711.8,868.1 711,864.6 711.4"/></svg></span>
</div>
</div>
</div>
<div class="intro__streaks" data-intro-streaks></div>
<div class="intro__bloom" data-intro-bloom></div>
<p class="intro__cue" data-intro-cue><span data-i18n="intro.cue">Scroll</span><span class="intro__cue-line"></span></p>
</div>
<section class="hero" id="top" aria-labelledby="hero-title">
<div class="hero__bg" aria-hidden="true">
<svg class="trails" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" focusable="false">
<defs>
<linearGradient id="trail-fade" x1="0" y1="0" x2="1" y2="0">
<stop offset="0" stop-color="#4d94ff" stop-opacity="0"/>
<stop offset=".45" stop-color="#4d94ff" stop-opacity=".22"/>
<stop offset="1" stop-color="#4d94ff" stop-opacity=".05"/>
</linearGradient>
</defs>
<g class="trails__base" stroke="url(#trail-fade)" fill="none" stroke-width="1">
<path d="M-40 760C380 720 760 600 1640 260"/>
<path d="M-40 842C460 822 980 702 1640 520"/>
<path d="M420 940C700 700 1080 520 1640 420"/>
<path d="M-40 430C300 470 520 600 760 940"/>
</g>
<g class="trails__comets" fill="none" stroke-linecap="round">
<path pathLength="1000" style="--dur:7.5s;--delay:-1.2s" d="M-40 760C380 720 760 600 1640 260"/>
<path pathLength="1000" style="--dur:9s;--delay:-5s" d="M-40 842C460 822 980 702 1640 520"/>
<path pathLength="1000" style="--dur:8.2s;--delay:-3.4s" d="M420 940C700 700 1080 520 1640 420"/>
<path pathLength="1000" style="--dur:10s;--delay:-7s" d="M-40 430C300 470 520 600 760 940"/>
</g>
</svg>
<div class="hero__glow"></div>
<div class="hero__horizon"></div>
</div>
<div class="container hero__grid">
<div class="hero__copy" data-hero-copy>
<p class="hero__eyebrow"><span class="dash is-on" aria-hidden="true"></span><span data-i18n-html="hero.eyebrow">Meta Ads <span>&times;</span> AI <span>&times;</span> Growth</span></p>
<h1 class="hero__title" id="hero-title" data-i18n-html="hero.title"><span class="line"><span>Scale smarter</span></span> <span class="line"><span>with <em>Meta Ads.</em></span></span></h1>
<p class="hero__lead" data-i18n="hero.lead">We help eCommerce brands scale profitably with data-driven Meta Ads, AI optimization and performance-focused strategy.</p>
<div class="hero__ctas">
<a class="btn btn--primary" href="<?php echo esc_url( scalium_contact_url() ); ?>" data-transition>
<span data-i18n="cta.contact">Contact us</span>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-right"/></svg>
</a>
<a class="btn btn--ghost" href="#services">
<span data-i18n="hero.secondary">See our services</span>
<svg class="icon icon--down" aria-hidden="true"><use href="#i-arrow-right"/></svg>
</a>
</div>
</div>
<div class="hero__visual" data-hero-visual>
<div class="hero__tilt" data-tilt>
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-560.avif 560w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-900.avif 900w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-1200.avif 1200w" sizes="(min-width: 1024px) 60vw, 100vw"><img class="hero__img" src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-900.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-560.webp 560w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-900.webp 900w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/hero-dashboard-1200.webp 1200w" sizes="(min-width: 1024px) 60vw, 100vw" width="972" height="750" alt="Scalium Meta Ads dashboard with total revenue, ROAS and active ad campaigns" data-i18n-attr="alt:hero.alt" fetchpriority="high" loading="eager" decoding="async"></picture>
</div>
</div>
</div>
</section>
</div>
<section class="statement" aria-labelledby="statement-text">
<div class="container">
<p class="statement__text" id="statement-text" data-scrub-words data-i18n="statement.text">Most brands don't have a traffic problem. They have a scaling problem. We build the system that turns ad spend into predictable revenue.</p>
<ul class="outcomes">
<li class="outcome" data-reveal style="--d:0">
<span class="dash" data-dash aria-hidden="true"></span>
<svg class="icon" aria-hidden="true"><use href="#i-trend-up"/></svg>
<span data-i18n="outcome.1">More revenue</span>
</li>
<li class="outcome" data-reveal style="--d:1">
<span class="dash" data-dash aria-hidden="true"></span>
<svg class="icon" aria-hidden="true"><use href="#i-target"/></svg>
<span data-i18n="outcome.2">Lower CAC</span>
</li>
<li class="outcome" data-reveal style="--d:2">
<span class="dash" data-dash aria-hidden="true"></span>
<svg class="icon" aria-hidden="true"><use href="#i-lightning"/></svg>
<span data-i18n="outcome.3">Long-term growth</span>
</li>
</ul>
</div>
</section>
<section class="services" id="services" aria-labelledby="services-title">
<div class="container">
<div class="section-head" data-reveal>
<div class="dash" data-dash aria-hidden="true"></div>
<h2 class="h2" id="services-title" data-i18n="services.title">Three services. One goal: profitable growth.</h2>
<p class="section-lead" data-i18n="services.lead">Choose one or combine all three. The same team, the same data and the same target behind each of them.</p>
</div>
<div class="services__layout" data-services>
<div class="services__list">
<article class="service is-active" data-service="0" aria-labelledby="svc1-title">
<div class="service__media">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.avif 1040w" sizes="(min-width: 960px) 1px, 92vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.webp 1040w" sizes="(min-width: 960px) 1px, 92vw" width="702" height="492" alt="" loading="lazy" decoding="async"></picture>
</div>
<h3 class="service__title" id="svc1-title" data-i18n="svc1.title">Brand scaling with Meta Ads</h3>
<p class="service__text" data-i18n="svc1.text">Facebook and Instagram campaigns built to grow spend without losing efficiency. We structure the account, find the audiences that buy and scale budgets on the signals that matter.</p>
<ul class="service__list">
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d1">Full-funnel campaign structure</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d2">Audience research and targeting</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d3">Budget scaling and bid strategy</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc1.d4">Advantage+ and catalog campaigns</span></li>
</ul>
</article>
<article class="service" data-service="1" aria-labelledby="svc2-title">
<div class="service__media">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.avif 940w" sizes="(min-width: 960px) 1px, 92vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.webp 940w" sizes="(min-width: 960px) 1px, 92vw" width="470" height="360" alt="" loading="lazy" decoding="async"></picture>
</div>
<h3 class="service__title" id="svc2-title" data-i18n="svc2.title">Marketing, run for you</h3>
<p class="service__text" data-i18n="svc2.text">We run your marketing day to day: creative production and testing, launches, reporting and optimization. You get a senior team without building one in-house.</p>
<ul class="service__list">
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d1">Creative strategy and production</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d2">Continuous creative testing</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d3">Campaign launches and promotions</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc2.d4">Clear weekly reporting</span></li>
</ul>
</article>
<article class="service" data-service="2" aria-labelledby="svc3-title">
<div class="service__media">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.avif 1040w" sizes="(min-width: 960px) 1px, 92vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.webp 1040w" sizes="(min-width: 960px) 1px, 92vw" width="548" height="276" alt="" loading="lazy" decoding="async"></picture>
</div>
<h3 class="service__title" id="svc3-title" data-i18n="svc3.title">Growth marketing</h3>
<p class="service__text" data-i18n="svc3.text">Growth comes from the whole funnel, not a single channel. We test offers, landing pages and retention flows, fix tracking and use the data to find your next stage of growth.</p>
<ul class="service__list">
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d1">Conversion rate optimization</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d2">Tracking with Pixel, CAPI and GA4</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d3">Offer and funnel experiments</span></li>
<li><svg class="icon" aria-hidden="true"><use href="#i-check"/></svg><span data-i18n="svc3.d4">Retention and LTV strategy</span></li>
</ul>
</article>
</div>
<div class="services__stage" aria-hidden="true">
<div class="stage">
<div class="stage__frame">
<div class="stage__slide is-active" data-slide="0">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.avif 1040w" sizes="(min-width: 960px) 46vw, 1px"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-meta-1040.webp 1040w" sizes="(min-width: 960px) 46vw, 1px" width="702" height="492" alt="" loading="lazy" decoding="async"></picture>
</div>
<div class="stage__slide" data-slide="1">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.avif 940w" sizes="(min-width: 960px) 40vw, 1px"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-managed-940.webp 940w" sizes="(min-width: 960px) 40vw, 1px" width="470" height="360" alt="" loading="lazy" decoding="async"></picture>
</div>
<div class="stage__slide" data-slide="2">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.avif 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.avif 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.avif 1040w" sizes="(min-width: 960px) 46vw, 1px"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-520.webp 520w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-760.webp 760w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/svc-growth-1040.webp 1040w" sizes="(min-width: 960px) 46vw, 1px" width="548" height="276" alt="" loading="lazy" decoding="async"></picture>
</div>
<span class="stage__scan" data-scan></span>
</div>
<div class="stage__progress"><span class="is-active"></span><span></span><span></span></div>
</div>
</div>
</div>
</div>
</section>
<section class="process" id="process" aria-labelledby="process-title">
<div class="process__pin" data-process>
<div class="process__track" data-process-track>
<div class="process__intro" data-reveal>
<div class="dash" data-dash aria-hidden="true"></div>
<h2 class="h2" id="process-title" data-i18n="process.title">From first ad to predictable scale.</h2>
<p class="section-lead" data-i18n="process.lead">Five stages, one loop. Every cycle feeds the next one with better data.</p>
<div class="process__emblem">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-420.avif 420w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-700.avif 700w" sizes="(min-width: 960px) 30vw, 80vw"><img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-700.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-420.webp 420w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/process-emblem-700.webp 700w" sizes="(min-width: 960px) 30vw, 80vw" width="352" height="232" alt="" loading="lazy" decoding="async"></picture>
</div>
</div>
<div class="process__steps" data-process-steps>
<div class="process__line" aria-hidden="true"><span class="process__fill" data-process-fill></span><span class="process__head" data-process-head></span></div>
<ol class="steps">
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-sparkle"/></svg><span data-i18n="step1.title">Create</span></h3>
<p class="step__text" data-i18n="step1.text">Ad creatives built on research and produced fast with AI, ready to test from day one.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-paper-plane-tilt"/></svg><span data-i18n="step2.title">Launch</span></h3>
<p class="step__text" data-i18n="step2.text">Campaigns go live across Facebook and Instagram with a clear testing plan.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-chart-bar"/></svg><span data-i18n="step3.title">Analyze</span></h3>
<p class="step__text" data-i18n="step3.text">We read the numbers that matter and turn them into decisions, not just reports.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-gear-six"/></svg><span data-i18n="step4.title">Automate</span></h3>
<p class="step__text" data-i18n="step4.text">Rules and AI-assisted optimization keep budgets working around the clock.</p>
</div>
</li>
<li class="step" data-step>
<span class="step__node" aria-hidden="true"></span>
<div class="step__card">
<h3 class="step__title"><svg class="icon" aria-hidden="true"><use href="#i-trend-up"/></svg><span data-i18n="step5.title">Scale</span></h3>
<p class="step__text" data-i18n="step5.text">Winning ads and audiences get more budget, so growth stays profitable as spend increases.</p>
</div>
</li>
</ol>
</div>
</div>
</div>
</section>
<section class="results" id="results" aria-labelledby="results-title">
<div class="container">
<div class="section-head section-head--center" data-reveal>
<h2 class="h2" id="results-title" data-i18n-html="results.title">Data-driven <em>growth.</em></h2>
<p class="section-lead" data-i18n="results.lead">Every decision is backed by numbers. These are the metrics we answer for.</p>
</div>
</div>
<div class="results__media" data-zoom>
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-640.avif 640w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1000.avif 1000w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1400.avif 1400w" sizes="(min-width: 1400px) 1300px, 94vw"><img class="results__img" src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1000.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-640.webp 640w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1000.webp 1000w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/results-dashboard-1400.webp 1400w" sizes="(min-width: 1400px) 1300px, 94vw" width="1214" height="554" alt="Performance dashboard with ad spend, conversions and a rising revenue chart" data-i18n-attr="alt:results.alt" loading="lazy" decoding="async"></picture>
</div>
<div class="container">
<dl class="stats" data-reveal>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-chart-bar"/></svg><span>ROAS</span></dt>
<dd data-count="42" data-sign="+">+42%</dd>
</div>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-users-three"/></svg><span data-i18n="stat.leads">Leads</span></dt>
<dd data-count="68" data-sign="+">+68%</dd>
</div>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-trend-up"/></svg><span data-i18n="stat.revenue">Revenue</span></dt>
<dd data-count="53" data-sign="+">+53%</dd>
</div>
<div class="stat">
<dt><svg class="icon" aria-hidden="true"><use href="#i-target"/></svg><span>CAC</span></dt>
<dd data-count="37" data-sign="&minus;">&minus;37%</dd>
</div>
</dl>
<p class="footnote" data-i18n="results.note">Illustrative figures. Results depend on brand, offer and budget.</p>
</div>
</section>
<section class="cta" id="contact-cta" aria-labelledby="cta-title">
<div class="container cta__content">
<h2 class="cta__title" id="cta-title" data-reveal data-i18n="cta.title">Growing together.</h2>
<p class="cta__sub" data-reveal style="--d:1" data-i18n="cta.sub">Meta Ads. Marketing. Growth Marketing.</p>
<div class="cta__action" data-reveal style="--d:2">
<a class="btn btn--primary btn--lg" href="<?php echo esc_url( scalium_contact_url() ); ?>" data-transition>
<span data-i18n="cta.button">Contact us for more information and pricing</span>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-right"/></svg>
</a>
</div>
</div>
<div class="cta__media" data-cta-media aria-hidden="true">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-800.avif 800w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.avif 1280w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1672.avif 1672w" sizes="100vw"><img class="cta__img" src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-800.webp 800w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.webp 1280w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1672.webp 1672w" sizes="100vw" width="1672" height="609" alt="" loading="lazy" decoding="async"></picture>
</div>
</section>
</main>

<?php get_footer();
