<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#020305">
<meta name="color-scheme" content="dark">
<meta name="robots" content="index, follow, max-image-preview:large">
<script>
/* Runs before first paint: marks JS as available, restores the chosen language
and starts the page-transition wipe when arriving from another Scalium page. */
(function (d) {
var h = d.documentElement;
h.className = h.className.replace('no-js', 'js');
try {
var q = new URLSearchParams(location.search).get('lang');
var stored = null;
try { stored = localStorage.getItem('scalium-lang'); } catch (e) {}
/* the /ro/ pages are Romanian by address; elsewhere the visitor's choice, then the browser */
h.setAttribute('data-page-lang', h.lang === 'ro' ? 'ro' : 'en');
/* on a /ro/ page, keep English if the visitor switched to it on the previous Scalium page */
var ref = null;
try { ref = new URL(d.referrer); } catch (e) {}
var refLang = ref && ref.origin === location.origin ? ref.searchParams.get('lang') : null;
var l = q || (h.lang === 'ro' ? (refLang === 'en' ? 'en' : 'ro') : stored || ((navigator.language || '').toLowerCase().indexOf('ro') === 0 ? 'ro' : 'en'));
l = l === 'ro' ? 'ro' : 'en';
h.lang = l;
h.setAttribute('data-lang', l);
if (sessionStorage.getItem('scalium-wipe') && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
h.classList.add('is-entering');
setTimeout(function () { h.classList.add('is-entered'); }, 1500); /* safety net if scripts fail */
}
sessionStorage.removeItem('scalium-wipe');
/* The logo intro plays from the top of the home page; a link to one of its sections skips it.
If the animation script failed (it has run by the time the page has loaded), drop the
intro so the hero is never left covered. A slow connection only delays it. */
if (/^#(top|main|services|process|results|contact-cta)$/.test(location.hash)) h.classList.add('intro-skip');
/* Back/forward returns to where the visitor was. (A reload of the home page starts at the top so the
intro replays: main.js marks the page for that when it is left.) */
var nav = performance.getEntriesByType ? performance.getEntriesByType('navigation')[0] : null;
window.__scaliumBack = !!nav && nav.type === 'back_forward';
/* a scroll the visitor made (wheel, touch, keys) vs. one a browser or an embedding viewer restored */
var moved = function () { window.__scaliumUserScrolled = true; };
['wheel', 'touchstart', 'keydown', 'pointerdown'].forEach(function (t) { window.addEventListener(t, moved, { passive: true, capture: true }); });
if (window.__scaliumBack && 'scrollRestoration' in history) history.scrollRestoration = 'auto';
window.addEventListener('load', function () {
if (!window.__scaliumIntro) h.classList.add('intro-skip', 'hero-go');
/* main.js never ran (blocked or failed): drop the animation-only styles so nothing stays hidden */
if (!window.__scaliumBoot) { h.classList.remove('js'); h.classList.add('no-js'); }
});
} catch (e) {}
})(document);
</script>
<link rel="preload" href="<?php echo esc_url( SCALIUM_URI ); ?>/assets/fonts/mona-display-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="<?php echo esc_url( SCALIUM_URI ); ?>/assets/fonts/mona-sans-latin.woff2" as="font" type="font/woff2" crossorigin>
<link rel="icon" href="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/logo-mark.svg" type="image/svg+xml">
<link rel="icon" href="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/favicon-32.png" sizes="32x32" type="image/png">
<link rel="apple-touch-icon" href="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/apple-touch-icon.png">
<?php wp_head(); ?>
</head>
<body  <?php body_class( 'site' ); ?> data-page="<?php echo esc_attr( scalium_page_key() ); ?>">
<?php wp_body_open(); ?>
<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><symbol id="i-arrow-right" viewBox="0 0 256 256"><path d="M221.66,133.66l-72,72a8,8,0,0,1-11.32-11.32L196.69,136H40a8,8,0,0,1,0-16H196.69L138.34,61.66a8,8,0,0,1,11.32-11.32l72,72A8,8,0,0,1,221.66,133.66Z"/></symbol><symbol id="i-arrow-up-right" viewBox="0 0 256 256"><path d="M200,64V168a8,8,0,0,1-16,0V83.31L69.66,197.66a8,8,0,0,1-11.32-11.32L172.69,72H88a8,8,0,0,1,0-16H192A8,8,0,0,1,200,64Z"/></symbol><symbol id="i-arrow-left" viewBox="0 0 256 256"><path d="M224,128a8,8,0,0,1-8,8H59.31l58.35,58.34a8,8,0,0,1-11.32,11.32l-72-72a8,8,0,0,1,0-11.32l72-72a8,8,0,0,1,11.32,11.32L59.31,120H216A8,8,0,0,1,224,128Z"/></symbol><symbol id="i-arrow-up" viewBox="0 0 256 256"><path d="M205.66,117.66a8,8,0,0,1-11.32,0L136,59.31V216a8,8,0,0,1-16,0V59.31L61.66,117.66a8,8,0,0,1-11.32-11.32l72-72a8,8,0,0,1,11.32,0l72,72A8,8,0,0,1,205.66,117.66Z"/></symbol><symbol id="i-sparkle" viewBox="0 0 256 256"><path d="M197.58,129.06,146,110l-19-51.62a15.92,15.92,0,0,0-29.88,0L78,110l-51.62,19a15.92,15.92,0,0,0,0,29.88L78,178l19,51.62a15.92,15.92,0,0,0,29.88,0L146,178l51.62-19a15.92,15.92,0,0,0,0-29.88ZM137,164.22a8,8,0,0,0-4.74,4.74L112,223.85,91.78,169A8,8,0,0,0,87,164.22L32.15,144,87,123.78A8,8,0,0,0,91.78,119L112,64.15,132.22,119a8,8,0,0,0,4.74,4.74L191.85,144ZM144,40a8,8,0,0,1,8-8h16V16a8,8,0,0,1,16,0V32h16a8,8,0,0,1,0,16H184V64a8,8,0,0,1-16,0V48H152A8,8,0,0,1,144,40ZM248,88a8,8,0,0,1-8,8h-8v8a8,8,0,0,1-16,0V96h-8a8,8,0,0,1,0-16h8V72a8,8,0,0,1,16,0v8h8A8,8,0,0,1,248,88Z"/></symbol><symbol id="i-paper-plane-tilt" viewBox="0 0 256 256"><path d="M227.32,28.68a16,16,0,0,0-15.66-4.08l-.15,0L19.57,82.84a16,16,0,0,0-2.49,29.8L102,154l41.3,84.87A15.86,15.86,0,0,0,157.74,248q.69,0,1.38-.06a15.88,15.88,0,0,0,14-11.51l58.2-191.94c0-.05,0-.1,0-.15A16,16,0,0,0,227.32,28.68ZM157.83,231.85l-.05.14,0-.07-40.06-82.3,48-48a8,8,0,0,0-11.31-11.31l-48,48L24.08,98.25l-.07,0,.14,0L216,40Z"/></symbol><symbol id="i-chart-bar" viewBox="0 0 256 256"><path d="M224,200h-8V40a8,8,0,0,0-8-8H152a8,8,0,0,0-8,8V80H96a8,8,0,0,0-8,8v40H48a8,8,0,0,0-8,8v64H32a8,8,0,0,0,0,16H224a8,8,0,0,0,0-16ZM160,48h40V200H160ZM104,96h40V200H104ZM56,144H88v56H56Z"/></symbol><symbol id="i-gear-six" viewBox="0 0 256 256"><path d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160Zm109.94-52.79a8,8,0,0,0-3.89-5.4l-29.83-17-.12-33.62a8,8,0,0,0-2.83-6.08,111.91,111.91,0,0,0-36.72-20.67,8,8,0,0,0-6.46.59L128,41.85,97.88,25a8,8,0,0,0-6.47-.6A112.1,112.1,0,0,0,54.73,45.15a8,8,0,0,0-2.83,6.07l-.15,33.65-29.83,17a8,8,0,0,0-3.89,5.4,106.47,106.47,0,0,0,0,41.56,8,8,0,0,0,3.89,5.4l29.83,17,.12,33.62a8,8,0,0,0,2.83,6.08,111.91,111.91,0,0,0,36.72,20.67,8,8,0,0,0,6.46-.59L128,214.15,158.12,231a7.91,7.91,0,0,0,3.9,1,8.09,8.09,0,0,0,2.57-.42,112.1,112.1,0,0,0,36.68-20.73,8,8,0,0,0,2.83-6.07l.15-33.65,29.83-17a8,8,0,0,0,3.89-5.4A106.47,106.47,0,0,0,237.94,107.21Zm-15,34.91-28.57,16.25a8,8,0,0,0-3,3c-.58,1-1.19,2.06-1.81,3.06a7.94,7.94,0,0,0-1.22,4.21l-.15,32.25a95.89,95.89,0,0,1-25.37,14.3L134,199.13a8,8,0,0,0-3.91-1h-.19c-1.21,0-2.43,0-3.64,0a8.08,8.08,0,0,0-4.1,1l-28.84,16.1A96,96,0,0,1,67.88,201l-.11-32.2a8,8,0,0,0-1.22-4.22c-.62-1-1.23-2-1.8-3.06a8.09,8.09,0,0,0-3-3.06l-28.6-16.29a90.49,90.49,0,0,1,0-28.26L61.67,97.63a8,8,0,0,0,3-3c.58-1,1.19-2.06,1.81-3.06a7.94,7.94,0,0,0,1.22-4.21l.15-32.25a95.89,95.89,0,0,1,25.37-14.3L122,56.87a8,8,0,0,0,4.1,1c1.21,0,2.43,0,3.64,0a8.08,8.08,0,0,0,4.1-1l28.84-16.1A96,96,0,0,1,188.12,55l.11,32.2a8,8,0,0,0,1.22,4.22c.62,1,1.23,2,1.8,3.06a8.09,8.09,0,0,0,3,3.06l28.6,16.29A90.49,90.49,0,0,1,222.9,142.12Z"/></symbol><symbol id="i-trend-up" viewBox="0 0 256 256"><path d="M240,56v64a8,8,0,0,1-16,0V75.31l-82.34,82.35a8,8,0,0,1-11.32,0L96,123.31,29.66,189.66a8,8,0,0,1-11.32-11.32l72-72a8,8,0,0,1,11.32,0L136,140.69,212.69,64H168a8,8,0,0,1,0-16h64A8,8,0,0,1,240,56Z"/></symbol><symbol id="i-check" viewBox="0 0 256 256"><path d="M229.66,77.66l-128,128a8,8,0,0,1-11.32,0l-56-56a8,8,0,0,1,11.32-11.32L96,188.69,218.34,66.34a8,8,0,0,1,11.32,11.32Z"/></symbol><symbol id="i-list" viewBox="0 0 256 256"><path d="M224,128a8,8,0,0,1-8,8H40a8,8,0,0,1,0-16H216A8,8,0,0,1,224,128ZM40,72H216a8,8,0,0,0,0-16H40a8,8,0,0,0,0,16ZM216,184H40a8,8,0,0,0,0,16H216a8,8,0,0,0,0-16Z"/></symbol><symbol id="i-x" viewBox="0 0 256 256"><path d="M205.66,194.34a8,8,0,0,1-11.32,11.32L128,139.31,61.66,205.66a8,8,0,0,1-11.32-11.32L116.69,128,50.34,61.66A8,8,0,0,1,61.66,50.34L128,116.69l66.34-66.35a8,8,0,0,1,11.32,11.32L139.31,128Z"/></symbol><symbol id="i-lightning" viewBox="0 0 256 256"><path d="M215.79,118.17a8,8,0,0,0-5-5.66L153.18,90.9l14.66-73.33a8,8,0,0,0-13.69-7l-112,120a8,8,0,0,0,3,13l57.63,21.61L88.16,238.43a8,8,0,0,0,13.69,7l112-120A8,8,0,0,0,215.79,118.17ZM109.37,214l10.47-52.38a8,8,0,0,0-5-9.06L62,132.71l84.62-90.66L136.16,94.43a8,8,0,0,0,5,9.06l52.8,19.8Z"/></symbol><symbol id="i-users-three" viewBox="0 0 256 256"><path d="M244.8,150.4a8,8,0,0,1-11.2-1.6A51.6,51.6,0,0,0,192,128a8,8,0,0,1-7.37-4.89,8,8,0,0,1,0-6.22A8,8,0,0,1,192,112a24,24,0,1,0-23.24-30,8,8,0,1,1-15.5-4A40,40,0,1,1,219,117.51a67.94,67.94,0,0,1,27.43,21.68A8,8,0,0,1,244.8,150.4ZM190.92,212a8,8,0,1,1-13.84,8,57,57,0,0,0-98.16,0,8,8,0,1,1-13.84-8,72.06,72.06,0,0,1,33.74-29.92,48,48,0,1,1,58.36,0A72.06,72.06,0,0,1,190.92,212ZM128,176a32,32,0,1,0-32-32A32,32,0,0,0,128,176ZM72,120a8,8,0,0,0-8-8A24,24,0,1,1,87.24,82a8,8,0,1,0,15.5-4A40,40,0,1,0,37,117.51,67.94,67.94,0,0,0,9.6,139.19a8,8,0,1,0,12.8,9.61A51.6,51.6,0,0,1,64,128,8,8,0,0,0,72,120Z"/></symbol><symbol id="i-target" viewBox="0 0 256 256"><path d="M221.87,83.16A104.1,104.1,0,1,1,195.67,49l22.67-22.68a8,8,0,0,1,11.32,11.32l-96,96a8,8,0,0,1-11.32-11.32l27.72-27.72a40,40,0,1,0,17.87,31.09,8,8,0,1,1,16-.9,56,56,0,1,1-22.38-41.65L184.3,60.39a87.88,87.88,0,1,0,23.13,29.67,8,8,0,0,1,14.44-6.9Z"/></symbol><symbol id="i-whatsapp-logo" viewBox="0 0 256 256"><path d="M187.58,144.84l-32-16a8,8,0,0,0-8,.5l-14.69,9.8a40.55,40.55,0,0,1-16-16l9.8-14.69a8,8,0,0,0,.5-8l-16-32A8,8,0,0,0,104,64a40,40,0,0,0-40,40,88.1,88.1,0,0,0,88,88,40,40,0,0,0,40-40A8,8,0,0,0,187.58,144.84ZM152,176a72.08,72.08,0,0,1-72-72A24,24,0,0,1,99.29,80.46l11.48,23L101,118a8,8,0,0,0-.73,7.51,56.47,56.47,0,0,0,30.15,30.15A8,8,0,0,0,138,155l14.61-9.74,23,11.48A24,24,0,0,1,152,176ZM128,24A104,104,0,0,0,36.18,176.88L24.83,210.93a16,16,0,0,0,20.24,20.24l34.05-11.35A104,104,0,1,0,128,24Zm0,192a87.87,87.87,0,0,1-44.06-11.81,8,8,0,0,0-6.54-.67L40,216,52.47,178.6a8,8,0,0,0-.66-6.54A88,88,0,1,1,128,216Z"/></symbol><symbol id="i-instagram-logo" viewBox="0 0 256 256"><path d="M128,80a48,48,0,1,0,48,48A48.05,48.05,0,0,0,128,80Zm0,80a32,32,0,1,1,32-32A32,32,0,0,1,128,160ZM176,24H80A56.06,56.06,0,0,0,24,80v96a56.06,56.06,0,0,0,56,56h96a56.06,56.06,0,0,0,56-56V80A56.06,56.06,0,0,0,176,24Zm40,152a40,40,0,0,1-40,40H80a40,40,0,0,1-40-40V80A40,40,0,0,1,80,40h96a40,40,0,0,1,40,40ZM192,76a12,12,0,1,1-12-12A12,12,0,0,1,192,76Z"/></symbol><symbol id="i-tiktok-logo" viewBox="0 0 256 256"><path d="M224,72a48.05,48.05,0,0,1-48-48,8,8,0,0,0-8-8H128a8,8,0,0,0-8,8V156a20,20,0,1,1-28.57-18.08A8,8,0,0,0,96,130.69V88a8,8,0,0,0-9.4-7.88C50.91,86.48,24,119.1,24,156a76,76,0,0,0,152,0V116.29A103.25,103.25,0,0,0,224,128a8,8,0,0,0,8-8V80A8,8,0,0,0,224,72Zm-8,39.64a87.19,87.19,0,0,1-43.33-16.15A8,8,0,0,0,160,102v54a60,60,0,0,1-120,0c0-25.9,16.64-49.13,40-57.6v27.67A36,36,0,1,0,136,156V32h24.5A64.14,64.14,0,0,0,216,87.5Z"/></symbol><symbol id="i-envelope-simple" viewBox="0 0 256 256"><path d="M224,48H32a8,8,0,0,0-8,8V192a16,16,0,0,0,16,16H216a16,16,0,0,0,16-16V56A8,8,0,0,0,224,48ZM203.43,64,128,133.15,52.57,64ZM216,192H40V74.19l82.59,75.71a8,8,0,0,0,10.82,0L216,74.19V192Z"/></symbol><symbol id="i-check-circle" viewBox="0 0 256 256"><path d="M173.66,98.34a8,8,0,0,1,0,11.32l-56,56a8,8,0,0,1-11.32,0l-24-24a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35A8,8,0,0,1,173.66,98.34ZM232,128A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128Z"/></symbol></svg>
<div class="wipe" aria-hidden="true"><span class="wipe__edge"></span></div>
<a class="skip-link" href="#main" data-i18n="skip">Skip to content</a>
<header class="nav" data-nav>
<div class="nav__inner">
<a class="nav__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="Scalium" data-home-link>
<img src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/logo-horizontal.svg" alt="Scalium" width="137" height="28">
</a>
<nav class="nav__links" aria-label="Primary" data-i18n-attr="aria-label:nav.label">
<a class="link" href="<?php echo esc_url( home_url( '/#services' ) ); ?>" data-i18n="nav.services">Services</a>
<a class="link" href="<?php echo esc_url( home_url( '/#process' ) ); ?>" data-i18n="nav.process">Process</a>
<a class="link" href="<?php echo esc_url( home_url( '/#results' ) ); ?>" data-i18n="nav.results">Results</a>
</nav>
<div class="nav__actions">
<a class="btn btn--primary btn--sm nav__cta" href="<?php echo esc_url( scalium_contact_url() ); ?>" data-transition>
<span data-i18n="cta.contact">Contact us</span>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-right"/></svg>
</a>
<div class="lang" role="group" aria-label="Language" data-i18n-attr="aria-label:lang.label">
<button type="button" class="lang__opt" data-lang="en" aria-pressed="true" lang="en">EN</button>
<button type="button" class="lang__opt" data-lang="ro" aria-pressed="false" lang="ro">RO</button>
<span class="lang__thumb" aria-hidden="true"></span>
</div>
<button type="button" class="nav__menu" aria-expanded="false" aria-controls="menu" data-menu-toggle>
<span class="sr-only" data-i18n="nav.menu">Menu</span>
<span class="nav__burger" aria-hidden="true"><span></span><span></span></span>
</button>
</div>
</div>
<div class="nav__progress" aria-hidden="true"><span data-scroll-progress></span></div>
</header>
<div class="menu" id="menu" data-menu hidden>
<nav class="menu__links" aria-label="Mobile" data-i18n-attr="aria-label:nav.mobile">
<a href="<?php echo esc_url( home_url( '/#services' ) ); ?>" style="--i:0"><span data-i18n="nav.services">Services</span><svg class="icon" aria-hidden="true"><use href="#i-arrow-up-right"/></svg></a>
<a href="<?php echo esc_url( home_url( '/#process' ) ); ?>" style="--i:1"><span data-i18n="nav.process">Process</span><svg class="icon" aria-hidden="true"><use href="#i-arrow-up-right"/></svg></a>
<a href="<?php echo esc_url( home_url( '/#results' ) ); ?>" style="--i:2"><span data-i18n="nav.results">Results</span><svg class="icon" aria-hidden="true"><use href="#i-arrow-up-right"/></svg></a>
<a href="<?php echo esc_url( scalium_contact_url() ); ?>" style="--i:3" data-transition><span data-i18n="cta.contact">Contact us</span><svg class="icon" aria-hidden="true"><use href="#i-arrow-up-right"/></svg></a>
</nav>
</div>
