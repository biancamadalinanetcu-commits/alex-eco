<?php
// Generated from src/config.json by scripts/build.mjs. Change values in Appearance > Customize > Scalium contact.
return array(
	'email' => 'scalium.buisiness@gmail.com',
	'whatsapp' => '40792535738',
	'whatsapp_display' => '+40 792 535 738',
	'instagram' => 'https://www.instagram.com/',
	'tiktok' => 'https://www.tiktok.com/',
);
