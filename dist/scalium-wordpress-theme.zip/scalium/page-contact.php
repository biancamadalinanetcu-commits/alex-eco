<?php get_header(); ?>

<main id="main" class="contact">
<section class="contact__hero" aria-labelledby="contact-title">
<div class="container contact__inner">
<a class="back-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" data-transition>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-left"/></svg>
<span data-i18n="contact.back">Back to home</span>
</a>
<h1 class="contact__title" id="contact-title" data-i18n-html="contact.title"><span class="line"><span>Let's talk about</span></span> <span class="line"><span><em>your growth.</em></span></span></h1>
<p class="contact__lead" data-i18n="contact.lead">More information and pricing for Meta Ads, marketing and growth marketing.</p>
<div class="contact__grid">
<aside class="contact__aside" aria-labelledby="direct-title">
<div class="dash" data-dash aria-hidden="true"></div>
<h2 class="contact__aside-title" id="direct-title" data-i18n="contact.direct">Prefer to talk now?</h2>
<p class="contact__aside-text" data-i18n="contact.directText">Message us on WhatsApp and talk directly with our team.</p>
<a class="btn btn--primary btn--wa" href="https://wa.me/<?php echo esc_attr( scalium_setting( 'whatsapp' ) ); ?>?text=Hi%20Scalium%2C%20I%20would%20like%20more%20information%20and%20pricing." target="_blank" rel="noopener" data-wa="<?php echo esc_attr( scalium_setting( 'whatsapp' ) ); ?>" data-wa-text="Hi Scalium, I would like more information and pricing." data-i18n-attr="data-wa-text:contact.waText">
<svg class="icon" aria-hidden="true"><use href="#i-whatsapp-logo"/></svg>
<span data-i18n="contact.wa">Message us on WhatsApp</span>
</a>
<dl class="contact__list">
<div>
<dt>WhatsApp</dt>
<dd><a class="link" href="https://wa.me/<?php echo esc_attr( scalium_setting( 'whatsapp' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( scalium_setting( 'whatsapp_display' ) ); ?></a></dd>
</div>
<div>
<dt>Email</dt>
<dd><a class="link" href="mailto:<?php echo esc_attr( scalium_setting( 'email' ) ); ?>"><?php echo esc_attr( scalium_setting( 'email' ) ); ?></a></dd>
</div>
</dl>
<div class="contact__follow">
<p class="contact__follow-label" data-i18n="contact.follow">Follow us</p>
<ul class="social" aria-label="Social media" data-i18n-attr="aria-label:social.label">
<li><a class="social__link" href="<?php echo esc_url( scalium_setting( 'instagram' ) ); ?>" target="_blank" rel="noopener" aria-label="Instagram"><svg class="icon" aria-hidden="true"><use href="#i-instagram-logo"/></svg></a></li>
<li><a class="social__link" href="<?php echo esc_url( scalium_setting( 'tiktok' ) ); ?>" target="_blank" rel="noopener" aria-label="TikTok"><svg class="icon" aria-hidden="true"><use href="#i-tiktok-logo"/></svg></a></li>
</ul>
</div>
</aside>
<form class="form" id="contact-form" action="<?php echo esc_url( admin_url( 'admin-post.php?action=scalium_contact' ) ); ?>" method="POST" novalidate data-contact-form data-endpoint="<?php echo esc_url( admin_url( 'admin-post.php?action=scalium_contact' ) ); ?>">
<div class="form__body" data-form-body>
<h2 class="form__title" data-i18n="form.title">Tell us about your brand</h2>
<input type="hidden" name="_subject" value="New request from the Scalium website">
<input type="hidden" name="_template" value="table">
<input type="hidden" name="language" value="English" data-form-lang>
<div class="form__hp" aria-hidden="true">
<label>Leave this field empty <input type="text" name="_honey" tabindex="-1" autocomplete="off"></label>
</div>
<fieldset class="field field--choice" data-field="service">
<legend class="field__label"><span data-i18n="form.service">What do you need?</span> <span class="field__hint" data-i18n="form.serviceHint">Choose one or more.</span></legend>
<div class="chips">
<label class="chip"><input type="checkbox" name="service" value="Meta Ads scaling"><span data-i18n="svc1.short">Meta Ads scaling</span></label>
<label class="chip"><input type="checkbox" name="service" value="Marketing management"><span data-i18n="svc2.short">Marketing management</span></label>
<label class="chip"><input type="checkbox" name="service" value="Growth marketing"><span data-i18n="svc3.short">Growth marketing</span></label>
<label class="chip"><input type="checkbox" name="service" value="Not sure yet"><span data-i18n="form.notSure">Not sure yet</span></label>
</div>
<p class="field__error" id="err-service" data-error-for="service" data-i18n="form.err.service" hidden>Choose at least one service.</p>
</fieldset>
<div class="field">
<label class="field__label" for="f-name" data-i18n="form.name">Name</label>
<input class="field__input" id="f-name" name="name" type="text" autocomplete="name" maxlength="120" required aria-describedby="err-name">
<p class="field__error" id="err-name" data-error-for="name" data-i18n="form.err.name" hidden>Please enter your name.</p>
</div>
<div class="form__pair">
<div class="field">
<label class="field__label" for="f-email" data-i18n="form.email">Email</label>
<input class="field__input" id="f-email" name="email" type="email" autocomplete="email" inputmode="email" maxlength="160" placeholder="you@brand.com" required aria-describedby="err-email">
<p class="field__error" id="err-email" data-error-for="email" data-i18n="form.err.email" hidden>Please enter a valid email address.</p>
</div>
<div class="field">
<label class="field__label" for="f-phone" data-i18n="form.phone">Phone number</label>
<input class="field__input" id="f-phone" name="phone" type="tel" autocomplete="tel" inputmode="tel" maxlength="40" placeholder="+40 7XX XXX XXX" required aria-describedby="err-phone">
<p class="field__error" id="err-phone" data-error-for="phone" data-i18n="form.err.phone" hidden>Please enter a valid phone number.</p>
</div>
</div>
<div class="field">
<label class="field__label" for="f-message"><span data-i18n="form.message">Project details</span> <span class="field__hint" data-i18n="form.optional">(optional)</span></label>
<textarea class="field__input field__input--area" id="f-message" name="message" rows="4" maxlength="3000" placeholder="Your brand, your goals and your monthly ad budget." data-i18n-attr="placeholder:form.messagePh"></textarea>
</div>
<div class="form__foot">
<button class="btn btn--primary form__submit" type="submit">
<span class="form__submit-label" data-i18n="form.submit">Send request</span>
<svg class="icon" aria-hidden="true"><use href="#i-paper-plane-tilt"/></svg>
</button>
<p class="form__privacy" data-i18n="form.privacy">We use your details only to reply to your request.</p>
</div>
<p class="form__status" role="status" aria-live="polite" data-form-status>
<span data-status="sending" data-i18n="form.sending" hidden>Sending your request...</span>
<span data-status="fail" hidden><span data-i18n="form.fail">Your request could not be sent. Please try again, or message us on WhatsApp.</span></span>
</p>
</div>
<div class="form__done" data-form-done hidden>
<svg class="icon form__done-icon" aria-hidden="true"><use href="#i-check-circle"/></svg>
<h2 class="form__title" tabindex="-1" data-i18n="form.okTitle">Request sent.</h2>
<p class="form__done-text" data-i18n="form.okText">Thank you. We will get back to you soon with more information and pricing.</p>
<button type="button" class="btn btn--ghost btn--sm" data-form-again>
<span data-i18n="form.again">Send another request</span>
</button>
</div>
</form>
</div>
<div class="contact__slot" data-contact-slot>
<?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?>
</div>
</div>
<div class="contact__bg" aria-hidden="true">
<video class="loop-video" data-loop-video muted loop playsinline disablepictureinpicture preload="none" tabindex="-1" width="1600" height="700"
data-poster="<?php echo esc_url( SCALIUM_URI ); ?>/assets/video/cta-arrow-poster.webp" data-poster-sm="<?php echo esc_url( SCALIUM_URI ); ?>/assets/video/cta-arrow-sm-poster.webp">
<source data-src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/video/cta-arrow.webm" data-src-sm="<?php echo esc_url( SCALIUM_URI ); ?>/assets/video/cta-arrow-sm.webm" type="video/webm">
<source data-src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/video/cta-arrow.mp4" data-src-sm="<?php echo esc_url( SCALIUM_URI ); ?>/assets/video/cta-arrow-sm.mp4" type="video/mp4">
</video>
</div>
</section>
</main>

<?php get_footer();
