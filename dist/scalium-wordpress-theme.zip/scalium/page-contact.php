<?php get_header(); ?>

<main id="main" class="contact">
<section class="contact__hero" aria-labelledby="contact-title">
<div class="container contact__inner">
<a class="back-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" data-transition>
<svg class="icon" aria-hidden="true"><use href="#i-arrow-left"/></svg>
<span data-i18n="contact.back">Back to home</span>
</a>
<h1 class="contact__title" id="contact-title" data-i18n-html="contact.title"><span class="line"><span>Let's talk about</span></span> <span class="line"><span><em>your growth.</em></span></span></h1>
<p class="contact__lead" data-i18n="contact.lead">More information and pricing for Meta Ads, marketing and growth marketing.</p>
<div class="contact__slot" data-contact-slot>
<?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?>
</div>
</div>
<div class="contact__bg" aria-hidden="true">
<picture><source type="image/avif" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-800.avif 800w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.avif 1280w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1672.avif 1672w" sizes="100vw"><img class="contact__img" src="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.webp" srcset="<?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-800.webp 800w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1280.webp 1280w, <?php echo esc_url( SCALIUM_URI ); ?>/assets/img/cta-orb-1672.webp 1672w" sizes="100vw" width="1672" height="609" alt="" fetchpriority="high" loading="eager" decoding="async"></picture>
</div>
</section>
</main>

<?php get_footer();
